﻿Application Developed and maintained by Keoto. Contact Keoto via email (keoto@outlook.com) or through Discord (username: Keoto).

1. Steps to installation
-Extract Folder to specified location. Do not remove any files from within.
-Launch Application

2. Using the Application
-Insert SteamID into checkbox and determine your refresh rate.
-Data will refresh based upon refresh rate or button click (button click will reset timer of auto refresh).
-Txt files are saved in your MyDocuments inside the BattleRoyaleStatFiles folder.

3. Github Source Code
-https://github.com/keoto/BattleRoyaleStatsApp